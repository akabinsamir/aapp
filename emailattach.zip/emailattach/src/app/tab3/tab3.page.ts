import { Component, SkipSelf } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  data: Observable<any>;
  public items:any;
 
  result:any=[];
 
  constructor(public navCtrl: NavController,public http: HttpClient) {
    this.loadData();
  }
  loadData(){
    let data:Observable<any>;
    data =this.http.get('https://5bcce576cf2e850013874767.mockapi.io/task/categories');
    data.subscribe(result =>{
      this.items= result;
   
      
    });
  }

}
